
#ifndef APPS_H
#define APPS_H

#include <drivers/mouse.h>

typedef bool (*MouseHandler)(MouseState, void*);
typedef bool (*KeyHandler)(char, void*);

typedef struct {
    void* app_data;
    void (*draw_func)(struct Window*, void*);
    MouseHandler mouse_handler;
    KeyHandler key_handler;
    bool needs_buffer;
} AppHandle;

// File manager
typedef struct {
    char current_path[256];
    FileEntry entries[50];
    int entry_count;
    int scroll_offset;
    bool needs_redraw;
    struct Window* window;
} FileManagerState;

FileManagerState* filemgr_create(AppHandle* handle, int x, int y, int w, int h);

// Terminal
typedef struct {
    char buffer[TERM_HEIGHT][TERM_WIDTH + 1];
    char cmd_history[MAX_HISTORY][TERM_WIDTH + 1];
    int cursor_x, cursor_y;
    int history_pos;
} TerminalState;

TerminalState* terminal_create(AppHandle* handle, int x, int y, int w, int h);

#endif
